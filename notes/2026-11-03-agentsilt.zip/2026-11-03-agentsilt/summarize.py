"""Summarize a directory of silt --json outputs, least crowded first.

Usage: python3 -I summarize.py OUT_DIR [--top N]
"""
import json
import pathlib
import sys

out = pathlib.Path(sys.argv[1])
top = int(sys.argv[sys.argv.index("--top") + 1]) if "--top" in sys.argv else 3
order = {"open": 0, "crowded": 1, "saturated": 2}
rows = []
for f in sorted(out.glob("*.json")):
    try:
        d = json.loads(f.read_text())
    except Exception as e:
        print(f"{f.name}: unreadable ({e})")
        continue
    m = d["matches"]
    sims = [x["similarity"] for x in m]
    rows.append((
        order[d["verdict"]["level"]],
        max(sims, default=0),
        f.stem,
        d["verdict"]["level"],
        d["query"],
        sum(s >= 0.55 for s in sims),
        d["verdict"]["sources_failed"],
        m[:top],
    ))
rows.sort(key=lambda r: (r[0], r[1]))
for _, mx, stem, level, q, n55, failed, best in rows:
    print(f"[{stem}] {level:9} max={mx:.2f} n>=.55={n55:2}  {q}")
    if failed:
        print(f"      FAILED: {failed}")
    for x in best:
        desc = (x["description"] or "").replace("\n", " ")[:90]
        print(f"      {x['similarity']:.2f} {x['source']:<10} {x['name']}: {desc}")
