#!/usr/bin/env bash
# Usage: run.sh IDEAS_FILE OUT_DIR
# Runs silt --json once per non-empty, non-# line; one JSON file per idea.
# Exit codes: 0 open, 1 crowded, 2 saturated.
set -u
ideas=$1 out=$2
mkdir -p "$out"
i=0
while IFS= read -r idea; do
  [[ -z "$idea" || "$idea" == \#* ]] && continue
  i=$((i+1))
  f=$(printf '%s/%03d.json' "$out" "$i")
  [[ -s "$f" ]] && continue
  silt --json --limit 20 "$idea" > "$f" 2> "${f%.json}.err"
  echo "$i exit=$? $idea" >&2
  [[ -s "${f%.json}.err" ]] || rm -f "${f%.json}.err"
  sleep 2   # stay well under GitHub's 30 searches/min
done < "$ideas"
